module.exports = {
  BOT_TOKEN: "8139080693:AAEeOXfcUDY2kxJQB5lLIN4EP8f7RwBky60", //Token Cretae aja di (@BotFather),Pertama di pencarian paste aja tu, udah tu lu /start, /newbot, lu isi nama bot, smaa username buat, dah tu ada bacaan api token, nah salin, tarok di atas.. 
  OWNER_ID: ["8424188433"], //@MissRose_bot create aja di bot rose dengan command /info nnti ada id salin aja
  OWNER_NAME: "𝐀𝐍𝐃𝐑𝐈 𝐒𝐓𝐎𝐑𝐄" //𝐍𝐚𝐦𝐚 𝐥𝐮 
};
